
  # Home Cleaning Services Website

  This is a code bundle for Home Cleaning Services Website. The original project is available at https://www.figma.com/design/izhtNkaebSfCKlPLQ4uZGp/Home-Cleaning-Services-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  